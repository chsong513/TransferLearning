# Transfer Learning
Joint Distribution Adaptation(JDA)

## Quick Start 
'''
pip install TransferLearning
'''




